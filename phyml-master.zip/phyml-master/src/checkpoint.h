#include <config.h>

#ifndef CHECKPOINT_H
#define CHECKPOINT_H

#include "utilities.h"

void CHECK_Main(int argc, char **argv);

#endif
